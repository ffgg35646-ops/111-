'use client';

import Link from 'next/link';
import styles from '../checkout.module.css';
import { useRouter } from 'next/navigation';
import { useEffect, useMemo, useState, type FormEvent } from 'react';
import { parseCartItemKey, useCart } from '@/components/CartProvider';
import { formatPrice, getProductPrice } from '@/lib/products';
import { CUSTOMER_EMAIL_STORAGE_KEY, getCustomerNotificationKey } from '@/lib/customer-notifications-client';

type WarrantyPolicy = {
  title: string;
  content: string;
  updatedAt: string | null;
  configured: boolean;
};

type CheckoutForm = {
  fullName: string;
  phone: string;
  email: string;
  idNumber: string;
  city: string;
  addressDetails: string;
  installment: 'yes' | 'no';
  installmentDownPayment: string;
  installmentMonths: string;
  acceptedPolicies: boolean;
};

const EMPTY_FORM: CheckoutForm = {
  fullName: '',
  phone: '',
  email: '',
  idNumber: '',
  city: '',
  addressDetails: '',
  installment: 'no',
  installmentDownPayment: '',
  installmentMonths: '',
  acceptedPolicies: false
};

function normalizeSaudiPhoneDigits(value: string) {
  return value
    .replace(/[٠-٩]/g, (digit) => String('٠١٢٣٤٥٦٧٨٩'.indexOf(digit)))
    .replace(/[۰-۹]/g, (digit) => String('۰۱۲۳۴۵۶۷۸۹'.indexOf(digit)));
}

function sanitizeSaudiPhoneInput(value: string) {
  return normalizeSaudiPhoneDigits(value).replace(/[^0-9]/g, '').slice(0, 10);
}

async function requestWarrantyPolicy(): Promise<WarrantyPolicy> {
  const response = await fetch('/api/store-content', { cache: 'no-store' });
  if (!response.ok) throw new Error('تعذر تحميل سياسة الضمان.');
  const data = await response.json() as {
    pages?: Array<{ key: string; title: string; content: string; updatedAt: string | null; configured?: boolean }>;
  };
  const saved = data.pages?.find((item) => item.key === 'warranty');
  if (!saved) throw new Error('صفحة سياسة الضمان غير متاحة.');
  return {
    title: saved.title || 'سياسة الضمان',
    content: saved.content || '',
    updatedAt: saved.updatedAt || null,
    configured: saved.configured === true
  };
}

export default function StoreCheckoutPage() {
  const router = useRouter();
  const { cart, hydrated, catalogProducts: products } = useCart();
  const [form, setForm] = useState<CheckoutForm>(EMPTY_FORM);
  const [formError, setFormError] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [warrantyPolicy, setWarrantyPolicy] = useState<WarrantyPolicy>({
    title: 'سياسة الضمان',
    content: 'جاري تحميل سياسة الضمان...',
    updatedAt: null,
    configured: false
  });
  const [policyLoading, setPolicyLoading] = useState(true);
  const [policyOpen, setPolicyOpen] = useState(false);
  const [policyLoadError, setPolicyLoadError] = useState('');

  useEffect(() => {
    let alive = true;
    requestWarrantyPolicy()
      .then((policy) => {
        if (alive) {
          setWarrantyPolicy(policy);
          setPolicyLoadError('');
        }
      })
      .catch((error) => {
        if (alive) {
          setWarrantyPolicy({
            title: 'سياسة الضمان',
            content: 'تعذر تحميل سياسة الضمان حاليًا. حاول تحديث الصفحة.',
            updatedAt: null,
            configured: false
          });
          setPolicyLoadError(error instanceof Error ? error.message : 'تعذر تحميل سياسة الضمان.');
        }
      })
      .finally(() => { if (alive) setPolicyLoading(false); });
    return () => { alive = false; };
  }, []);

  useEffect(() => {
    try {
      const raw = window.sessionStorage.getItem('erd-algwal-checkout-draft-v1');
      const savedDraft = raw ? JSON.parse(raw) as Partial<CheckoutForm> & { neighborhood?: string; street?: string; building?: string; notes?: string } : {};
      const savedEmail = window.localStorage.getItem(CUSTOMER_EMAIL_STORAGE_KEY) || '';
      const restored: CheckoutForm = {
        ...EMPTY_FORM,
        fullName: typeof savedDraft.fullName === 'string' ? savedDraft.fullName : '',
        phone: typeof savedDraft.phone === 'string' ? sanitizeSaudiPhoneInput(savedDraft.phone) : '',
        email: savedEmail.trim() || (typeof savedDraft.email === 'string' ? savedDraft.email : ''),
        idNumber: typeof savedDraft.idNumber === 'string' ? normalizeSaudiPhoneDigits(savedDraft.idNumber).replace(/[^0-9]/g, '').slice(0, 10) : '',
        city: typeof savedDraft.city === 'string' ? savedDraft.city : '',
        addressDetails: typeof savedDraft.addressDetails === 'string'
          ? savedDraft.addressDetails
          : [savedDraft.neighborhood, savedDraft.street, savedDraft.building, savedDraft.notes].filter((part): part is string => typeof part === 'string' && part.trim().length > 0).join('، '),
        installment: savedDraft.installment === 'yes' ? 'yes' : 'no',
        installmentDownPayment: ['500', '750', '1000', '1500', '2000'].includes(String(savedDraft.installmentDownPayment ?? '')) ? String(savedDraft.installmentDownPayment) : '',
        installmentMonths: ['3', '6', '10', '12', '24'].includes(String(savedDraft.installmentMonths ?? '')) ? String(savedDraft.installmentMonths) : '',
        acceptedPolicies: savedDraft.acceptedPolicies === true
      };
      setForm(restored);
      if (restored.email.trim()) window.localStorage.setItem(CUSTOMER_EMAIL_STORAGE_KEY, restored.email.trim());
    } catch {
      // A malformed local draft should never block checkout.
    }
  }, []);

  const cartLines = useMemo(() => Object.entries(cart).map(([cartKey, quantity]) => {
    const { productId, color, storage } = parseCartItemKey(cartKey);
    return { cartKey, color, storage, product: products.find((item) => item.id === productId), quantity };
  }).filter((line) => Boolean(line.product)), [cart]);

  const total = cartLines.reduce((sum, line) => sum + (line.product ? getProductPrice(line.product, line.storage) : 0) * line.quantity, 0);
  async function openWarrantyPolicy() {
    setPolicyOpen(true);
    setPolicyLoading(true);
    setPolicyLoadError('');
    try {
      const latestPolicy = await requestWarrantyPolicy();
      if (warrantyPolicy.updatedAt && latestPolicy.updatedAt !== warrantyPolicy.updatedAt) {
        setForm((current) => ({ ...current, acceptedPolicies: false }));
      }
      setWarrantyPolicy(latestPolicy);
    } catch (error) {
      setPolicyLoadError(error instanceof Error ? error.message : 'تعذر تحميل سياسة الضمان.');
    } finally {
      setPolicyLoading(false);
    }
  }

  function setField<K extends keyof CheckoutForm>(key: K, value: CheckoutForm[K]) {
    setForm((current) => ({ ...current, [key]: value }));
    setFormError('');
  }

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (isSubmitting) return;
    setFormError('');

    if (!cartLines.length) {
      setFormError('سلة المشتريات فارغة. أضف المنتجات أولًا ثم ارجع لإتمام البيانات.');
      return;
    }
    if (!form.city.trim()) {
      setFormError('اكتب المدينة.');
      return;
    }
    if (!form.addressDetails.trim()) {
      setFormError('اكتب تفاصيل العنوان.');
      return;
    }
    if (form.installment === 'yes' && (
      !['500', '750', '1000', '1500', '2000'].includes(form.installmentDownPayment) ||
      !['3', '6', '10', '12', '24'].includes(form.installmentMonths)
    )) {
      setFormError('اختر الدفعة المقدمة ومدة التقسيط.');
      return;
    }
    if (form.installment === 'yes') {
      const selectedInstallment = Number(form.installmentDownPayment);
      const selectedMonths = Number(form.installmentMonths);
      const totalCents = Math.round(total * 100);
      const coveredCents = Math.round(selectedInstallment * 100) * selectedMonths;
      if (selectedInstallment >= total || coveredCents < totalCents) {
        setFormError('صحح القسط من فضلك.');
        return;
      }
    }
    const cleanPhone = normalizeSaudiPhoneDigits(form.phone);
    if (!/^05[0-9]{8}$/.test(cleanPhone)) {
      setFormError('اكتب رقم جوال سعودي من 10 أرقام يبدأ بـ 05، مثل 05XXXXXXXX.');
      return;
    }
    const cleanIdNumber = normalizeSaudiPhoneDigits(form.idNumber).replace(/[^0-9]/g, '');
    if (!/^[12][0-9]{9}$/.test(cleanIdNumber)) {
      setFormError('من فضلك عدّل رقم الهوية فقط.');
      return;
    }
    if (policyLoading) {
      setFormError('انتظر تحميل سياسة الضمان ثم حاول مرة أخرى.');
      return;
    }
    if (!warrantyPolicy.configured || !warrantyPolicy.updatedAt) {
      setFormError('لا يمكن إكمال الطلب قبل أن تضيف الإدارة سياسة الضمان المعتمدة.');
      return;
    }
    if (!form.acceptedPolicies) {
      setFormError('يجب قراءة سياسة الضمان والموافقة عليها بعلامة الصح قبل إكمال الطلب.');
      return;
    }

    const items = cartLines.map(({ product, quantity, color, storage }) => ({
      productId: product!.id,
      quantity,
      ...(color ? { color } : {}),
      ...(storage ? { storage } : {})
    }));
    const payload = {
      fullName: form.fullName.trim(),
      phone: cleanPhone,
      email: form.email.trim(),
      idNumber: cleanIdNumber,
      city: form.city,
      addressDetails: form.addressDetails.trim(),
      installment: form.installment,
      installmentDownPayment: form.installment === 'yes' ? Number(form.installmentDownPayment) : null,
      installmentMonths: form.installment === 'yes' ? Number(form.installmentMonths) : null,
      acceptedPolicies: form.acceptedPolicies,
      warrantyPolicyUpdatedAt: warrantyPolicy.updatedAt,
      items
    };
    const fingerprint = JSON.stringify(payload);

    try {
      setIsSubmitting(true);
      let submissionId = '';
      try {
        const previousRaw = window.sessionStorage.getItem('erd-algwal-checkout-draft-v1');
        if (previousRaw) {
          const previous = JSON.parse(previousRaw) as { submissionId?: string; submissionFingerprint?: string; orderId?: string };
          if (previous.submissionFingerprint === fingerprint && typeof previous.submissionId === 'string' && !previous.orderId) {
            submissionId = previous.submissionId;
          }
        }
      } catch {
        // A malformed local draft is replaced below.
      }
      if (!submissionId) submissionId = window.crypto.randomUUID();

      let reviewToken = '';
      try {
        reviewToken = window.localStorage.getItem('erd-algwal-review-token') || '';
        if (!reviewToken) {
          reviewToken = window.crypto.randomUUID();
          window.localStorage.setItem('erd-algwal-review-token', reviewToken);
        }
      } catch {
        reviewToken = window.crypto.randomUUID();
      }

      const customerNotificationKey = getCustomerNotificationKey();
      const checkoutDraft = {
        ...form,
        ...payload,
        items: cartLines.map(({ product, quantity, color, storage }) => ({
          productId: product!.id,
          name: product!.name,
          unitPrice: getProductPrice(product!, storage),
          quantity,
          ...(color ? { color } : {}),
          ...(storage ? { storage } : {})
        })),
        total,
        currency: 'SAR',
        submissionId,
        submissionFingerprint: fingerprint,
        customerNotificationKey,
        reviewToken,
        savedAt: new Date().toISOString(),
        stage: 'phone-verification'
      };

      // Save the checkout draft and create the order. The admin notification is
      // intentionally sent only after the customer completes the payment step.
      window.sessionStorage.setItem('erd-algwal-checkout-draft-v1', JSON.stringify(checkoutDraft));
      const response = await fetch('/api/orders', {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({
          ...payload,
          submissionId,
          reviewToken,
          customerNotificationKey
        })
      });
      const result = await response.json() as {
        ok?: boolean;
        orderId?: string;
        orderNumber?: string;
        notificationSent?: boolean;
        error?: string;
        message?: string;
      };
      if (!response.ok || !result.ok || !result.orderId) {
        throw new Error(result.error || 'تعذر إرسال الطلب للإدارة. حاول مرة أخرى.');
      }
      window.sessionStorage.setItem('erd-algwal-checkout-draft-v1', JSON.stringify({
        ...checkoutDraft,
        orderId: result.orderId,
        orderNumber: result.orderNumber || '',
      }));
      router.push('/checkout/payment');
    } catch (error) {
      setFormError(error instanceof Error ? error.message : 'تعذر تجهيز تأكيد رقم الهاتف. حاول مرة أخرى.');
    } finally {
      setIsSubmitting(false);
    }
  }

  if (!hydrated) {
    return <main className={`${styles.checkoutShell} container checkout-page`}><div className="cart-loading">جاري تحميل سلة المشتريات...</div></main>;
  }

  return (
    <main className={`${styles.checkoutShell} container checkout-page`}>
      <div className="breadcrumbs">
        <Link href="/">الرئيسية</Link><span>/</span><Link href="/cart">سلة المشتريات</Link><span>/</span><span>إنهاء الطلب</span>
      </div>

      {!cartLines.length ? (
        <section className="checkout-empty">
          <div className="empty-cart-icon"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M3 4h2l2.1 10.1a2 2 0 0 0 2 1.6h7.8a2 2 0 0 0 1.9-1.4L21 8H6" /><circle cx="10" cy="20" r="1.2" /><circle cx="18" cy="20" r="1.2" /></svg></div>
          <h2>سلتك فاضية</h2>
          <p>أضف المنتجات اللي تحتاجها، وبعدها ارجع لإدخال بيانات التوصيل.</p>
          <Link href="/#categories" className="primary-button">تصفح المنتجات</Link>
        </section>
      ) : (
        <div className="checkout-layout">
          <form className="checkout-form-card" onSubmit={handleSubmit}>
            <section className="checkout-form-section checkout-contact-fields">
              <div className="checkout-section-heading"><div><h2>بيانات التواصل</h2></div></div>
              <div className="checkout-fields-grid">
                <label className="checkout-field checkout-field-full">
                  <input name="fullName" value={form.fullName} onChange={(event) => setField('fullName', event.target.value)} placeholder="الاسم بالكامل" autoComplete="name" required minLength={2} />
                </label>
                <label className="checkout-field checkout-field-full">
                  <input name="phone" type="tel" dir="ltr" value={form.phone} onChange={(event) => setField('phone', sanitizeSaudiPhoneInput(event.target.value))} placeholder="رقم الجوال 05XXXXXXXX" inputMode="numeric" autoComplete="tel-national" maxLength={10} minLength={10} required />
                </label>
                <label className="checkout-field checkout-field-full">
                  <input name="email" type="text" inputMode="email" value={form.email} onChange={(event) => {
                    const value = event.target.value;
                    setField('email', value);
                    try { window.localStorage.setItem(CUSTOMER_EMAIL_STORAGE_KEY, value); } catch { /* Keep checkout usable without browser storage. */ }
                  }} placeholder="البريد الإلكتروني (اختياري)" autoComplete="email" autoCapitalize="none" autoCorrect="off" spellCheck={false} required={false} />
                </label>
                <label className="checkout-field checkout-field-full">
                  <input name="idNumber" value={form.idNumber} onChange={(event) => setField('idNumber', normalizeSaudiPhoneDigits(event.target.value).replace(/[^0-9]/g, '').slice(0, 10))} placeholder="رقم الهوية / الإقامة (10 أرقام)" inputMode="numeric" autoComplete="off" maxLength={10} minLength={10} pattern="[0-9]{10}" required />
                </label>
              </div>
            </section>

            <section className="checkout-form-section checkout-contact-fields">
              <div className="checkout-fields-grid">
                <label className="checkout-field checkout-field-full">
                  <input
                    name="city"
                    value={form.city}
                    onChange={(event) => setField('city', event.target.value)}
                    placeholder="المدينة"
                    autoComplete="address-level2"
                    required
                  />
                </label>
                <label className="checkout-field checkout-field-full">
                  <input name="addressDetails" value={form.addressDetails} onChange={(event) => setField('addressDetails', event.target.value)} placeholder="تفاصيل العنوان (الحي، الشارع، رقم المبنى)" autoComplete="street-address" required />
                </label>
              </div>
            </section>

            <section className="checkout-form-section checkout-extra-options">
              <div className="installment-heading-row">
                <button
                  type="button"
                  className={form.installment === 'yes' ? 'installment-toggle active' : 'installment-toggle'}
                  aria-pressed={form.installment === 'yes'}
                  onClick={() => {
                    setForm((current) => ({
                      ...current,
                      installment: current.installment === 'yes' ? 'no' : 'yes',
                      installmentDownPayment: '',
                      installmentMonths: ''
                    }));
                    setFormError('');
                  }}
                >
                  <span>هل تريد تقسيط الجهاز؟</span>
                  <span className="installment-switch" aria-hidden="true"><span /></span>
                </button>
              </div>
              {form.installment === 'yes' ? (
                <div className="installment-details">
                  <div className="checkout-fields-grid">
                    <label className="checkout-field">
                      <select name="installmentDownPayment" value={form.installmentDownPayment} onChange={(event) => setField('installmentDownPayment', event.target.value)} required>
                        <option value="">اختر الدفعة المقدمة</option>
                        <option value="500">500 ريال</option>
                        <option value="750">750 ريال</option>
                        <option value="1000">1000 ريال</option>
                        <option value="1500">1500 ريال</option>
                        <option value="2000">2000 ريال</option>
                      </select>
                    </label>
                    <label className="checkout-field">
                      <select name="installmentMonths" value={form.installmentMonths} onChange={(event) => setField('installmentMonths', event.target.value)} required>
                        <option value="">اختر المدة</option>
                        <option value="3">3 شهور</option>
                        <option value="6">6 شهور</option>
                        <option value="10">10 شهور</option>
                        <option value="12">12 شهر</option>
                        <option value="24">24 شهر</option>
                      </select>
                    </label>
                  </div>
                </div>
              ) : null}
              <div className="policy-consent">
                <input
                  id="checkout-policy-accepted"
                  type="checkbox"
                  checked={form.acceptedPolicies}
                  onChange={(event) => setField('acceptedPolicies', event.target.checked)}
                  required
                />
                <div className="policy-consent-text">
                  <label htmlFor="checkout-policy-accepted">أوافق على </label>
                  <button type="button" className="policy-modal-link" onClick={openWarrantyPolicy}>سياسة الضمان</button>
                  <span> وأتعهد بالالتزام بالشروط.</span>
                </div>
              </div>
            </section>

            {formError ? <div className="checkout-alert checkout-alert-error" role="alert"><span>!</span>{formError}</div> : null}
            <div className="checkout-form-actions">
              <Link href="/cart" className="outline-button">العودة للسلة</Link>
              <button type="submit" className="primary-button checkout-submit" disabled={isSubmitting}>{isSubmitting ? 'جارٍ تجهيز التأكيد...' : 'تأكيد رقم الطلب'} <span aria-hidden="true">←</span></button>
            </div>

            {policyOpen ? (
              <div className="policy-modal-backdrop" role="presentation" onClick={() => setPolicyOpen(false)}>
                <section
                  className="policy-modal"
                  role="dialog"
                  aria-modal="true"
                  aria-labelledby="checkout-policy-title"
                  onClick={(event) => event.stopPropagation()}
                >
                  <header className="policy-modal-header">
                    <h2 id="checkout-policy-title">{warrantyPolicy.title}</h2>
                    <button type="button" className="policy-modal-close" aria-label="إغلاق" onClick={() => setPolicyOpen(false)}>×</button>
                  </header>
                  <div className="policy-modal-content">
                    {policyLoading ? 'جاري تحميل الشروط...' : policyLoadError || warrantyPolicy.content}
                    {!policyLoading && !warrantyPolicy.configured ? (
                      <p className="policy-modal-warning">لم تنشر الإدارة سياسة الضمان بعد، لذلك لن يمكن إكمال الطلب حتى إضافتها.</p>
                    ) : null}
                  </div>
                  <footer className="policy-modal-footer">
                    <button type="button" className="primary-button" onClick={() => setPolicyOpen(false)}>إغلاق</button>
                  </footer>
                </section>
              </div>
            ) : null}
          </form>

          <aside className="checkout-order-summary checkout-order-summary-compact">
            <h2>ملخص طلبك</h2>
            <div className="checkout-order-items">
              {cartLines.map(({ cartKey, product, color, storage, quantity }) => product ? (
                <div className="checkout-order-item" key={cartKey}>
                  <img src={product.image} alt={product.name} />
                  <div><strong>{product.name}</strong>{color ? <small>اللون: {color}</small> : null}{storage ? <small>مساحة التخزين: {storage}</small> : null}<small>الكمية: {quantity}</small></div>
                  <b>{formatPrice(getProductPrice(product, storage) * quantity)}</b>
                </div>
              ) : null)}
            </div>
            <div className="checkout-total-row"><span>عدد القطع</span><strong>{cartLines.reduce((sum, line) => sum + line.quantity, 0)}</strong></div>
            
            <div className="checkout-grand-total"><span>الإجمالي الحالي</span><strong>{formatPrice(total)}</strong></div>
          </aside>
        </div>
      )}
    </main>
  );
}
